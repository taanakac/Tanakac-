var subBtn = document.getElementById('subButton');
subBtn.addEventListener("click",addRow);


var tabe = document.getElementById('tab1');

function addRow(){
    
    
    var fName = document.getElementById("fname").value, sName = document.getElementById("sName").value,userAge = document.getElementById("uAge").value;
    
    localStorage.setItem("first_name",fName);
    localStorage.setItem('last_name',sName);
    localStorage.setItem('user_age',userAge);
    
    if(!fName||!sName||!userAge){
        alert("missing information!");
    }else{
        if(userAge>=18 && userAge<150){
            var newRow = tabe.insertRow(tabe.length);
            var cell = newRow.insertCell(0);
            var cell1 = newRow.insertCell(1);
            var cell2 = newRow.insertCell(2);

            cell.innerHTML = fName;
            cell1.innerHTML = sName;
            cell2.innerHTML =userAge;
        } else{
            alert("Age is invalid");
        }
       
    }
}

tabe.addEventListener('click', (e) => {
    if (e.target.classList.contains('remove-btn')) {
      e.target.closest('td').remove();
    }
  });
  